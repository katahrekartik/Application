package com.example.kartik.finalapplication;
import android.content.Intent;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {


    EditText etext;
    Button btn;
    EditText pword;
    TextView tview;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        ActionBar actionBar = getSupportActionBar();
        actionBar.setIcon(R.mipmap.flogo);
        actionBar.setTitle("Smart Bin App");
        actionBar.setDisplayUseLogoEnabled(true);
        actionBar.setDisplayShowHomeEnabled(true);

        etext = findViewById(R.id.etext);
        btn = findViewById(R.id.btn);
        pword = findViewById(R.id.pword);
        tview = findViewById(R.id.tview);

        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String name = etext.getText().toString().trim();
                String name1 = "kartik";
                String id = pword.getText().toString().trim();
                String id1 = "123456";

                if(etext.getText().toString().trim().isEmpty()||pword.getText().toString().trim().isEmpty()){

                    Toast.makeText(MainActivity.this,"please Fill the fields",Toast.LENGTH_SHORT).show();

                }

                else if(name.equals(name1)&&id.equals(id1)){

                    Intent intent = new Intent(MainActivity.this,com.example.kartik.finalapplication.Homepage.class);
                    startActivity(intent);
                }
                else{
                    tview.setText("Incorrect username or password!!");

                }

            }
        });

    }


}