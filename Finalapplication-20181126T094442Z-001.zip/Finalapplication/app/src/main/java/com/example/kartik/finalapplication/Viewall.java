package com.example.kartik.finalapplication;

import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.content.Intent;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import org.w3c.dom.Text;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

public class Viewall extends AppCompatActivity {
    ListView list1;
    ListView list2;
    ListView list3;

    Button b1,b2,b3,b4;
    private BluetoothAdapter BA;
    private Set<BluetoothDevice> pairedDevices;
    ListView lv;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_viewall);

        ActionBar actionBar = getSupportActionBar();
        actionBar.setIcon(R.mipmap.flogo);
        actionBar.setTitle("All Dustbins");
        actionBar.setDisplayUseLogoEnabled(true);
        actionBar.setDisplayHomeAsUpEnabled(true);

        list1  =(ListView) findViewById(R.id.list1);
        list2  =(ListView) findViewById(R.id.list2);
        list3  =(ListView) findViewById(R.id.list3);

        b1 = (Button) findViewById(R.id.button);

        b4=(Button)findViewById(R.id.button4);

        BA = BluetoothAdapter.getDefaultAdapter();





        DatabaseHandler db = new DatabaseHandler(Viewall.this);
        List<contact> c = db.getAllContacts();

        String names1[] = new String[c.size()];
        for(int i=0;i<c.size();i++){
            names1[i]=new Integer(c.get(i).getid()).toString();
        }
        String[] names2 = new String[c.size()];
        for(int i=0;i<c.size();i++){
            names2[i]=c.get(i).getname();
        }


        String[] names3 = new String[c.size()];
        for(int i=0;i<c.size();i++){
            names3[i]=c.get(i).getdis();
        }

        final ArrayAdapter<String> adapter1 = new ArrayAdapter<String>(this,
                android.R.layout.simple_list_item_1, android.R.id.text1, names1);
        list1.setAdapter(adapter1);



        final ArrayAdapter<String> adapter2 = new ArrayAdapter<String>(this,
                android.R.layout.simple_list_item_1, android.R.id.text1, names2);
        list2.setAdapter(adapter2);

        final ArrayAdapter<String> adapter3 = new ArrayAdapter<String>(this,
                android.R.layout.simple_list_item_1, android.R.id.text1, names3);
        list3.setAdapter(adapter3);

        list1.setVisibility(View.INVISIBLE);
        list2.setVisibility(View.INVISIBLE);
        list3.setVisibility(View.INVISIBLE);




        list1.setOnItemClickListener(new AdapterView.OnItemClickListener() {

            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                // TODO Auto-generated method stub
                if(position == 0) {
                    //code specific to first list item
                    Intent intent = new Intent(Viewall.this,com.example.kartik.finalapplication.binstatus.class);
                    startActivity(intent);

                }

                else if(position == 1) {
                    //code specific to 2nd list item
                    Intent intent = new Intent(Viewall.this,com.example.kartik.finalapplication.binstatus.class);
                    startActivity(intent);

                }

                else if(position == 2) {

                    Intent intent = new Intent(Viewall.this,com.example.kartik.finalapplication.binstatus.class);
                    startActivity(intent);

                }
                else if(position == 3) {

                    Intent intent = new Intent(Viewall.this,com.example.kartik.finalapplication.binstatus.class);
                    startActivity(intent);

                }
                else if(position == 4) {

                    Intent intent = new Intent(Viewall.this,com.example.kartik.finalapplication.binstatus.class);
                    startActivity(intent);

                }




            }
        });



        list3.setOnItemClickListener(new AdapterView.OnItemClickListener() {

            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                // TODO Auto-generated method stub
                if(position == 0) {
                    //code specific to first list item
                    Intent intent = new Intent(Viewall.this,com.example.kartik.finalapplication.binstatus.class);
                    startActivity(intent);

                }

                else if(position == 1) {
                    //code specific to 2nd list item
                    Intent intent = new Intent(Viewall.this,com.example.kartik.finalapplication.binstatus.class);
                    startActivity(intent);

                }

                else if(position == 2) {

                    Intent intent = new Intent(Viewall.this,com.example.kartik.finalapplication.binstatus.class);
                    startActivity(intent);

                }
                else if(position == 3) {

                    Intent intent = new Intent(Viewall.this,com.example.kartik.finalapplication.binstatus.class);
                    startActivity(intent);

                }
                else if(position == 4) {

                    Intent intent = new Intent(Viewall.this,com.example.kartik.finalapplication.binstatus.class);
                    startActivity(intent);

                }




            }
        });


        list2.setOnItemClickListener(new AdapterView.OnItemClickListener() {

            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                // TODO Auto-generated method stub
                if(position == 0) {
                    //code specific to first list item
                    Intent intent = new Intent(Viewall.this,com.example.kartik.finalapplication.binstatus.class);
                    startActivity(intent);

                }

                else if(position == 1) {
                    //code specific to 2nd list item
                    Intent intent = new Intent(Viewall.this,com.example.kartik.finalapplication.binstatus.class);
                    startActivity(intent);

                }

                else if(position == 2) {

                    Intent intent = new Intent(Viewall.this,com.example.kartik.finalapplication.binstatus.class);
                    startActivity(intent);

                }
                else if(position == 3) {

                    Intent intent = new Intent(Viewall.this,com.example.kartik.finalapplication.binstatus.class);
                    startActivity(intent);

                }
                else if(position == 4) {

                    Intent intent = new Intent(Viewall.this,com.example.kartik.finalapplication.binstatus.class);
                    startActivity(intent);

                }




            }
        });









    }



    public void on(View v){
        if (!BA.isEnabled()) {
            Intent turnOn = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
            startActivityForResult(turnOn, 0);
            Toast.makeText(getApplicationContext(), "Turned on",Toast.LENGTH_LONG).show();


        } else {
            Toast.makeText(getApplicationContext(), "Already on", Toast.LENGTH_LONG).show();
        }

        list1.setVisibility(View.VISIBLE);

        list2.setVisibility(View.VISIBLE);

        list3.setVisibility(View.VISIBLE);



    }

    public void off(View v){
        BA.disable();
        Toast.makeText(getApplicationContext(), "Turned off" ,Toast.LENGTH_LONG).show();

        list1.setVisibility(View.INVISIBLE);
        list2.setVisibility(View.INVISIBLE);
        list3.setVisibility(View.INVISIBLE);
    }


    @Override
    public boolean onCreatePanelMenu(int featureId, Menu menu) {
        getMenuInflater().inflate(R.menu.main,menu);
        return super.onCreatePanelMenu(featureId, menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        switch (item.getItemId()){

            case R.id.logout:
                Intent intent = new Intent(Viewall.this,com.example.kartik.finalapplication.MainActivity.class);
                startActivity(intent);
                break;
        }

        return super.onOptionsItemSelected(item);




    }


}
