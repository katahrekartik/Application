package com.example.kartik.finalapplication;
public class contact {

    private int ID;
    private String NAME;
    private String DIS;

    public contact(){

    }
    public contact(int id,String name, String dis){
        NAME = name;
        DIS = dis;
        ID = id;
    }
    public contact(int id,String name){
        NAME = name;
        ID=id;
    }

    public contact(int id){

        ID=id;
    }
    public int getid(){
        return ID;
    }

    public void setid(int id){

        ID = id;
    }
    public String getname(){
        return NAME;
    }

    public void setname(String name){

        NAME = name;
    }
    public String getdis(){
        return DIS;
    }

    public void setdis(String dis){

        DIS = dis;
    }


}
