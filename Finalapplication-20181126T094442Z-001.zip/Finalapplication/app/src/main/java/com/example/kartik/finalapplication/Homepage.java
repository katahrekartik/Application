package com.example.kartik.finalapplication;

import android.content.Intent;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

public class Homepage extends AppCompatActivity {

    ImageView viewimg,setimg;
    Button create;
    EditText eno,eid,etext,id;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_homepage);
        viewimg = findViewById(R.id.viewimg);
        setimg = findViewById(R.id.setimg);

        ActionBar actionBar = getSupportActionBar();
        actionBar.setIcon(R.mipmap.flogo);
        actionBar.setTitle("Welcome!!");
        actionBar.setDisplayUseLogoEnabled(true);
        actionBar.setDisplayHomeAsUpEnabled(true);




        viewimg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(Homepage.this,com.example.kartik.finalapplication.Viewall.class);
                startActivity(intent);


            }
        });

        setimg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(Homepage.this,com.example.kartik.finalapplication.manage.class);
                startActivity(intent);


            }
        });








    }


    @Override
    public boolean onCreatePanelMenu(int featureId, Menu menu) {
        getMenuInflater().inflate(R.menu.main,menu);
        return super.onCreatePanelMenu(featureId, menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        switch (item.getItemId()){


            case R.id.logout:
                Intent intent = new Intent(Homepage.this,com.example.kartik.finalapplication.MainActivity.class);
                startActivity(intent);
                break;
        }

        return super.onOptionsItemSelected(item);




    }
}
