package com.example.kartik.finalapplication;

import android.content.Intent;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

public class manage extends AppCompatActivity {

    Button delete;
    Button subbtn;
    EditText eno,eid,etext,id;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_manage);

        delete = findViewById(R.id.delete);
        subbtn = findViewById(R.id.subbtn);
        eno = findViewById(R.id.eno);
        eid = findViewById(R.id.eid);
        etext = findViewById(R.id.etext);
        id = findViewById(R.id.id);

        ActionBar actionBar = getSupportActionBar();
        actionBar.setIcon(R.mipmap.flogo);
        actionBar.setTitle("Manage Dustbins");
        actionBar.setDisplayUseLogoEnabled(true);
        actionBar.setDisplayHomeAsUpEnabled(true);



        subbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String id = eid.getText().toString().trim();
                int no = Integer.parseInt(eno.getText().toString().trim());
                DatabaseHandler db = new DatabaseHandler(manage.this);
                db.addContact(new contact(no,id,etext.getText().toString().trim()));
                Toast.makeText(manage.this,"succecfully saved",
                        Toast.LENGTH_SHORT).show();
                etext.setText("");
                eno.setText("");
                eid.setText("");

            }
        });

        delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                int idd = Integer.parseInt(id.getText().toString());
                DatabaseHandler db = new DatabaseHandler(manage.this);
                db.deleteContact(new contact(idd));
                Toast.makeText(manage.this,"succecfully deleted item",
                        Toast.LENGTH_SHORT).show();




            }
        });

    }


    @Override
    public boolean onCreatePanelMenu(int featureId, Menu menu) {
        getMenuInflater().inflate(R.menu.main,menu);
        return super.onCreatePanelMenu(featureId, menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        switch (item.getItemId()){


            case R.id.logout:
                Intent intent = new Intent(manage.this,com.example.kartik.finalapplication.MainActivity.class);
                startActivity(intent);
                break;
        }

        return super.onOptionsItemSelected(item);




    }
}
